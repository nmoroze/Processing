"d00dl3r" V 1.0 by Serv Software Windows Version

*********INSTRUCTIONS***************
Key commands:
'q' - increase brush size
'w' - decrease brush size
'c' - clear screen
 
To draw, hold down left mouse button while moving mouse to where you want to draw.

