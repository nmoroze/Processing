"d00dl3r" V 1.2 by Serv Software Windows Version

*********INSTRUCTIONS***************
Key commands:
'q' - increase brush size
'w' - decrease brush size
'c' - clear screen
's' - save image as a png file, entitled "doodle1" for your first doodle, "doodle2" for your second, etc.
'1' - set brush color to black
'2' - set brush color to red
'3' - set brush color to green
'4' - set brush color to blue
'5' - set brush color to orange
'6' - set brush color to magenta
'7' - set brush color to yellow
'8' - set brush color to teal
'9' - set brush color to grey
'0' - set brush color to white (eraser)
 
To draw, hold down left mouse button while moving mouse to where you want to draw.

*********Release Notes**************
V 1.0 - initial release of d00dl3r, with basic drawing and clear screen commands.
V 1.1 - addition of colors, image save system, and bigger canvas size.
V 1.2 - addition of extra colors and several bug fixes.

