"d00dl3r" V 1.1 by Serv Software Windows Version

*********INSTRUCTIONS***************
Key commands:
'q' - increase brush size
'w' - decrease brush size
'c' - clear screen
's' - save image as a png file, entitled "doodle1" for your first doodle, "doodle2" for your second, etc.
'1' - set brush color to black
'2' - set brush color to red
'3' - set brush color to green
'4' - set brush color to blue
'5' - set brush color to orange
'6' - set brush color to magenta
'7' - set brush color to yellow
 
To draw, hold down left mouse button while moving mouse to where you want to draw.

